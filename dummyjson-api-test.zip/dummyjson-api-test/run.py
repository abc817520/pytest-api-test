import os

os.system("pytest -s")
os.system("allure serve report")
